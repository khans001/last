import React, { useContext, useMemo, FormEvent, useState } from 'react';
import { AppContext } from '../context/AppContext';
import Button from './ui/Button';
import Input from './ui/Input';

const Checkout: React.FC = () => {
  const { cart, clearCart, setView } = useContext(AppContext);
  const [formState, setFormState] = useState({
      email: '', name: '', address: '', city: '', zip: '',
      card: '', expiry: '', cvc: ''
  });

  const subtotal = useMemo(() => cart.reduce((sum, item) => sum + item.price * item.quantity, 0), [cart]);
  const shipping = subtotal > 0 ? 5.00 : 0;
  const taxes = subtotal * 0.08; // 8% tax
  const total = subtotal + shipping + taxes;

  const handleSubmit = (e: FormEvent) => {
      e.preventDefault();
      // Basic validation
      for (const key in formState) {
          if (formState[key as keyof typeof formState].trim() === '') {
              alert(`Please fill out the ${key} field.`);
              return;
          }
      }
      alert('Order placed successfully! Thank you for your purchase.');
      clearCart();
      setView('home');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormState(prev => ({...prev, [id]: value}));
  }

  if (cart.length === 0) {
      return (
        <div className="text-center py-16">
            <h2 className="text-2xl font-bold mb-4">Your Cart is Empty</h2>
            <p className="text-gray-600 mb-6">You can't checkout without any items. Let's find something for you!</p>
            <Button onClick={() => setView('home')}>Go Shopping</Button>
        </div>
      );
  }

  return (
    <div className="lg:grid lg:grid-cols-2 lg:gap-x-12">
        <div className="mt-10 lg:mt-0">
            <h2 className="text-lg font-medium text-gray-900">Order summary</h2>
            <div className="mt-4 bg-white border border-gray-200 rounded-lg shadow-sm">
                <ul role="list" className="divide-y divide-gray-200">
                    {cart.map((product) => (
                        <li key={product.id} className="flex py-6 px-4">
                            <img src={product.imageUrl} alt={product.name} className="flex-none w-20 h-20 rounded-md object-center object-cover" />
                            <div className="ml-4 flex-auto flex flex-col justify-between">
                                <div>
                                    <h3 className="text-sm font-medium text-gray-900">{product.name}</h3>
                                    <p className="text-gray-500 text-sm">Qty: {product.quantity}</p>
                                </div>
                                <p className="mt-2 text-sm font-medium text-gray-900">${(product.price * product.quantity).toFixed(2)}</p>
                            </div>
                        </li>
                    ))}
                </ul>
                <dl className="border-t border-gray-200 py-6 px-4 space-y-6">
                    <div className="flex items-center justify-between"><dt>Subtotal</dt><dd>${subtotal.toFixed(2)}</dd></div>
                    <div className="flex items-center justify-between"><dt>Shipping</dt><dd>${shipping.toFixed(2)}</dd></div>
                    <div className="flex items-center justify-between"><dt>Taxes</dt><dd>${taxes.toFixed(2)}</dd></div>
                    <div className="flex items-center justify-between border-t border-gray-200 pt-6 font-medium text-gray-900"><dt>Total</dt><dd>${total.toFixed(2)}</dd></div>
                </dl>
            </div>
        </div>

        <div className="pt-10">
            <form onSubmit={handleSubmit} className="space-y-8">
                <div>
                    <h2 className="text-lg font-medium text-gray-900">Contact Information</h2>
                    <div className="mt-4">
                        <Input label="Email address" id="email" name="email" type="email" autoComplete="email" onChange={handleChange} required />
                    </div>
                </div>

                <div>
                    <h2 className="text-lg font-medium text-gray-900">Shipping Information</h2>
                    <div className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
                        <div className="sm:col-span-2"><Input label="Full name" id="name" name="name" autoComplete="name" onChange={handleChange} required /></div>
                        <div className="sm:col-span-2"><Input label="Address" id="address" name="address" autoComplete="street-address" onChange={handleChange} required /></div>
                        <div><Input label="City" id="city" name="city" autoComplete="address-level2" onChange={handleChange} required /></div>
                        <div><Input label="Postal code" id="zip" name="zip" autoComplete="postal-code" onChange={handleChange} required /></div>
                    </div>
                </div>

                <div>
                    <h2 className="text-lg font-medium text-gray-900">Payment Details</h2>
                    <div className="mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-4 sm:gap-x-4">
                        <div className="sm:col-span-4"><Input label="Card number" id="card" name="card" type="text" onChange={handleChange} required /></div>
                        <div className="sm:col-span-2"><Input label="Expiration date (MM/YY)" id="expiry" name="expiry" type="text" onChange={handleChange} required /></div>
                        <div><Input label="CVC" id="cvc" name="cvc" type="text" onChange={handleChange} required /></div>
                    </div>
                </div>

                <div className="border-t border-gray-200 pt-6">
                    <Button type="submit" className="w-full text-lg">Place Order</Button>
                </div>
            </form>
        </div>
    </div>
  );
};

export default Checkout;