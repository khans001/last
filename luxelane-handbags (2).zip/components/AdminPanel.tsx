import React, { useState, useContext, FormEvent, useRef } from 'react';
import { AppContext } from '../context/AppContext';
import type { Product } from '../types';
import Button from './ui/Button';
import Input from './ui/Input';
import ProductForm from './ProductForm';

const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('products');
  const { exportSettings, importSettings, setView } = useContext(AppContext);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (file) {
          try {
              await importSettings(file);
          } catch (error) {
              console.error("Import failed:", error);
          }
          // Reset file input to allow re-uploading the same file name
          if(event.target) event.target.value = '';
      }
  };
  
  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">Admin Panel</h2>
        <div className="flex items-center space-x-2">
           <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept=".json"
          />
          <Button variant="secondary" onClick={handleImportClick}>
            Import Changes
          </Button>
          <Button variant="secondary" onClick={exportSettings}>
            Export Changes
          </Button>
          <Button variant="secondary" onClick={() => setView('home')}>
            View Site
          </Button>
        </div>
      </div>

      <div className="flex border-b">
        <TabButton title="Products" activeTab={activeTab} onClick={setActiveTab} />
        <TabButton title="Categories" activeTab={activeTab} onClick={setActiveTab} />
        <TabButton title="Site Settings" activeTab={activeTab} onClick={setActiveTab} />
        <TabButton title="Account" activeTab={activeTab} onClick={setActiveTab} />
      </div>

      <div className="py-8">
        {activeTab === 'products' && <ProductsManagement />}
        {activeTab === 'categories' && <CategoriesManagement />}
        {activeTab === 'site-settings' && <SiteSettings />}
        {activeTab === 'account' && <AccountSettings />}
      </div>
    </div>
  );
};

interface TabButtonProps {
    title: string;
    activeTab: string;
    onClick: (name: string) => void;
}

const TabButton: React.FC<TabButtonProps> = ({ title, activeTab, onClick }) => {
    const id = title.toLowerCase().replace(' ', '-');
    const isActive = activeTab === id;
    return (
        <button
            onClick={() => onClick(id)}
            className={`px-4 py-2 font-semibold border-b-2 transition-colors ${isActive ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-primary'}`}
        >
            {title}
        </button>
    );
};

const ProductsManagement = () => {
    const { products, deleteProduct } = useContext(AppContext);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);

    const handleEdit = (product: Product) => {
        setEditingProduct(product);
        setIsFormOpen(true);
    };

    const handleAddNew = () => {
        setEditingProduct(null);
        setIsFormOpen(true);
    };

    const handleDelete = (productId: string) => {
        if(window.confirm('Are you sure you want to delete this product? This action is permanent.')){
            deleteProduct(productId);
        }
    };
    
    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold">Manage Products ({products.length})</h3>
                <Button onClick={handleAddNew}>Add New Product</Button>
            </div>
             <ProductForm 
                isOpen={isFormOpen}
                onClose={() => setIsFormOpen(false)}
                product={editingProduct}
            />
            <div className="bg-white shadow rounded-lg overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {products.map(p => (
                            <tr key={p.id}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                        <div className="flex-shrink-0 h-10 w-10">
                                            <img className="h-10 w-10 rounded-md object-cover" src={p.imageUrl} alt={p.name} />
                                        </div>
                                        <div className="ml-4">
                                            <div className="text-sm font-medium text-gray-900">{p.name}</div>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{p.category}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${p.price.toFixed(2)}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                    <button onClick={() => handleEdit(p)} className="text-primary hover:text-gray-700">Edit</button>
                                    <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-900">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const CategoriesManagement = () => {
    const { categories, addCategory, deleteCategory } = useContext(AppContext);
    const [newCategoryName, setNewCategoryName] = useState('');

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (newCategoryName.trim()) {
            addCategory({ id: `cat-${Date.now()}`, name: newCategoryName.trim() });
            setNewCategoryName('');
        }
    };

    const handleDelete = (categoryId: string) => {
        if(window.confirm('Deleting a category will not delete its products, but they will become uncategorized. Continue?')){
            deleteCategory(categoryId);
        }
    };

    return (
        <div className="max-w-lg">
            <h3 className="text-xl font-semibold mb-4">Manage Categories</h3>
            <form onSubmit={handleSubmit} className="flex gap-2 mb-6">
                <Input
                    id="new-category"
                    label="New Category Name"
                    value={newCategoryName}
                    onChange={e => setNewCategoryName(e.target.value)}
                    className="flex-grow"
                    placeholder="e.g., Backpacks"
                />
                <Button type="submit" className="self-end">Add</Button>
            </form>
            <ul className="space-y-2">
                {categories.filter(c => c.id !== '1').map(c => (
                    <li key={c.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                        <span className="text-gray-800">{c.name}</span>
                        <button onClick={() => handleDelete(c.id)} className="text-red-500 hover:text-red-700 font-semibold">Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const SiteSettings = () => {
    const { siteName, setSiteName } = useContext(AppContext);
    const [currentSiteName, setCurrentSiteName] = useState(siteName);

    const handleSave = (e: FormEvent) => {
        e.preventDefault();
        setSiteName(currentSiteName);
        alert('Site name updated!');
    };

    return (
        <div className="max-w-lg">
            <h3 className="text-xl font-semibold mb-4">Site Name</h3>
            <form onSubmit={handleSave} className="space-y-4">
                <Input 
                    id="site-name"
                    label="Site Name"
                    value={currentSiteName}
                    onChange={e => setCurrentSiteName(e.target.value)}
                />
                <Button type="submit">Save Changes</Button>
            </form>
        </div>
    );
};

const AccountSettings = () => {
    const { adminEmail, updateAdminCredentials } = useContext(AppContext);
    const [email, setEmail] = useState(adminEmail);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleSave = (e: FormEvent) => {
        e.preventDefault();
        if(password && password !== confirmPassword){
            alert("Passwords do not match.");
            return;
        }
        updateAdminCredentials(email, password || undefined);
        alert('Credentials updated successfully. Password is changed only if a new one is provided.');
        setPassword('');
        setConfirmPassword('');
    };

    return (
         <div className="max-w-lg">
            <h3 className="text-xl font-semibold mb-4">Account Settings</h3>
            <form onSubmit={handleSave} className="space-y-4">
                <p className="text-sm text-gray-600">Change your login email or set a new password. Leave password fields blank to keep the current one.</p>
                <Input 
                    id="admin-email"
                    label="Admin Email"
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                />
                 <Input 
                    id="admin-password"
                    label="New Password"
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                />
                 <Input 
                    id="admin-confirm-password"
                    label="Confirm New Password"
                    type="password"
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                />
                <Button type="submit">Save Changes</Button>
            </form>
        </div>
    );
};

export default AdminPanel;