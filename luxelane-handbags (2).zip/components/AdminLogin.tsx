import React, { useState, useContext, FormEvent } from 'react';
import { AppContext } from '../context/AppContext';
import Input from './ui/Input';
import Button from './ui/Button';

const AdminLogin: React.FC = () => {
  const { login, setView } = useContext(AppContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (login(email, password)) {
      setView('adminPanel');
    } else {
      setError('Incorrect email or password. Please try again.');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-8 border rounded-lg shadow-lg bg-white">
      <h2 className="text-2xl font-bold text-center mb-6">Admin Login</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <Input
          id="email"
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="email"
        />
        <Input
          id="password"
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <div className="flex items-center justify-between">
           <Button type="button" variant="secondary" onClick={() => setView('home')}>Cancel</Button>
           <Button type="submit">Log In</Button>
        </div>
      </form>
    </div>
  );
};

export default AdminLogin;