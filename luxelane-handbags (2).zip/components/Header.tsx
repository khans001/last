import React, { useContext, useState, useMemo } from 'react';
import { AppContext } from '../context/AppContext';
import Button from './ui/Button';
import Cart from './Cart';

const CartIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
);

const Header: React.FC = () => {
  const { siteName, isAdmin, logout, cart, setView } = useContext(AppContext);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setView('home');
  };
  
  const totalItems = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  return (
    <>
      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <header className="bg-secondary border-b border-gray-200 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <h1 
            className="text-2xl font-bold tracking-tight cursor-pointer text-primary"
            onClick={() => setView('home')}
          >
            {siteName}
          </h1>
          <div className="flex items-center space-x-4">
            {isAdmin ? (
              <>
                <Button variant="secondary" onClick={() => setView('adminPanel')}>Admin Panel</Button>
                <Button variant="primary" onClick={handleLogout}>Logout</Button>
              </>
            ) : (
                <>
                 <button onClick={() => setIsCartOpen(true)} className="relative text-primary hover:text-gray-600 p-2 rounded-full hover:bg-gray-200 transition-colors">
                    <CartIcon />
                    {totalItems > 0 && (
                        <span className="absolute top-0 right-0 block h-5 w-5 rounded-full bg-accent text-white text-xs flex items-center justify-center transform translate-x-1/2 -translate-y-1/2">
                            {totalItems}
                        </span>
                    )}
                 </button>
                 <Button onClick={() => setView('adminLogin')}>Admin Login</Button>
                </>
            )}
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;