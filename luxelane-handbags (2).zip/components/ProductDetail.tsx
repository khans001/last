import React, { useContext } from 'react';
import { AppContext } from '../context/AppContext';
import Button from './ui/Button';

const ProductDetail: React.FC = () => {
  const { selectedProduct, setView, addToCart } = useContext(AppContext);

  if (!selectedProduct) {
    return (
      <div className="text-center py-16">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="text-gray-600 mb-6">The product you are looking for does not exist or has been moved.</p>
        <Button onClick={() => setView('home')}>Back to Shopping</Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(selectedProduct);
    // Maybe show a notification here in a future version
  };

  return (
    <div>
        <button onClick={() => setView('home')} className="mb-8 text-sm font-semibold text-gray-600 hover:text-primary">
            &larr; Back to all products
        </button>
        <div className="grid md:grid-cols-2 gap-12 items-start">
            {/* Image Column */}
            <div className="bg-gray-100 rounded-lg overflow-hidden">
                <img
                    src={selectedProduct.imageUrl}
                    alt={selectedProduct.name}
                    className="w-full h-full object-cover object-center aspect-[1/1]"
                />
            </div>

            {/* Details Column */}
            <div className="flex flex-col h-full py-4">
                <span className="text-sm font-semibold text-gray-500 uppercase tracking-wider">{selectedProduct.category}</span>
                <h1 className="text-4xl font-bold text-primary mt-2">{selectedProduct.name}</h1>
                <p className="text-3xl font-semibold text-primary my-4">${selectedProduct.price.toFixed(2)}</p>
                
                <div className="prose prose-lg text-gray-700 mt-4">
                    <p>{selectedProduct.description}</p>
                </div>

                <div className="mt-auto pt-8">
                     <Button onClick={handleAddToCart} className="w-full text-lg py-3">
                        Add to Cart
                     </Button>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ProductDetail;
