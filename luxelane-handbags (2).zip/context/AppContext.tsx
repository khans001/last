import React, { createContext, useState, useMemo, useCallback, useEffect } from 'react';
import type { AppContextType, Product, Category, CartItem, View } from '../types';
import { INITIAL_SITE_NAME, INITIAL_PRODUCTS, INITIAL_CATEGORIES } from '../constants';

// Helper function to get initial state from localStorage or use a default
const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const storedValue = localStorage.getItem(key);
        if (storedValue) {
            return JSON.parse(storedValue);
        }
    } catch (error) {
        console.error(`Error reading from localStorage for key "${key}":`, error);
    }
    return defaultValue;
};


const defaultState: AppContextType = {
    siteName: INITIAL_SITE_NAME,
    setSiteName: () => {},
    products: INITIAL_PRODUCTS,
    setProducts: () => {},
    categories: INITIAL_CATEGORIES,
    setCategories: () => {},
    isAdmin: false,
    login: () => false,
    logout: () => {},
    adminEmail: 'kingkhan00100923@gmail.com',
    updateAdminCredentials: () => {},
    addProduct: () => {},
    updateProduct: () => {},
    deleteProduct: () => {},
    addCategory: () => {},
    deleteCategory: () => {},
    cart: [],
    addToCart: () => {},
    removeFromCart: () => {},
    updateCartQuantity: () => {},
    clearCart: () => {},
    exportSettings: () => {},
    importSettings: async () => {},
    view: 'home',
    setView: () => {},
    selectedProduct: null,
    setSelectedProduct: () => {},
};

export const AppContext = createContext<AppContextType>(defaultState);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [siteName, setSiteName] = useState<string>(() => getInitialState('luxelane_siteName', INITIAL_SITE_NAME));
    const [products, setProducts] = useState<Product[]>(() => getInitialState('luxelane_products', INITIAL_PRODUCTS));
    const [categories, setCategories] = useState<Category[]>(() => getInitialState('luxelane_categories', INITIAL_CATEGORIES));
    const [isAdmin, setIsAdmin] = useState<boolean>(false);
    const [adminCredentials, setAdminCredentials] = useState(() => getInitialState('luxelane_adminCreds', {
        email: 'kingkhan00100923@gmail.com',
        password: 'iamawebdeveloper@001',
    }));
    const [cart, setCart] = useState<CartItem[]>([]); // Cart is not persisted
    const [view, setView] = useState<View>('home');
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);


    // Effects to save state to localStorage whenever it changes
    useEffect(() => {
        localStorage.setItem('luxelane_siteName', JSON.stringify(siteName));
    }, [siteName]);

    useEffect(() => {
        localStorage.setItem('luxelane_products', JSON.stringify(products));
    }, [products]);

    useEffect(() => {
        localStorage.setItem('luxelane_categories', JSON.stringify(categories));
    }, [categories]);
    
    useEffect(() => {
        localStorage.setItem('luxelane_adminCreds', JSON.stringify(adminCredentials));
    }, [adminCredentials]);

    const login = useCallback((email: string, password: string): boolean => {
        if (email.toLowerCase() === adminCredentials.email.toLowerCase() && password === adminCredentials.password) {
            setIsAdmin(true);
            return true;
        }
        return false;
    }, [adminCredentials.email, adminCredentials.password]);

    const logout = useCallback(() => {
        setIsAdmin(false);
    }, []);

    const updateAdminCredentials = useCallback((email?: string, password?: string) => {
        setAdminCredentials(prev => ({
            email: email || prev.email,
            password: password || prev.password
        }));
    }, []);
    
    const addProduct = (product: Product) => {
        setProducts(prev => [product, ...prev]);
    };

    const updateProduct = (updatedProduct: Product) => {
        setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    };

    const deleteProduct = (productId: string) => {
        setProducts(prev => prev.filter(p => p.id !== productId));
    };

    const addCategory = (category: Category) => {
        setCategories(prev => [...prev, category]);
    };

    const deleteCategory = (categoryId: string) => {
        if(categoryId === '1') return; // Cannot delete 'All Handbags'
        setCategories(prev => prev.filter(c => c.id !== categoryId));
    };

    // Cart Logic
    const addToCart = (product: Product) => {
        setCart(prevCart => {
            const existingItem = prevCart.find(item => item.id === product.id);
            if (existingItem) {
                return prevCart.map(item =>
                    item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
                );
            }
            return [...prevCart, { ...product, quantity: 1 }];
        });
    };

    const removeFromCart = (productId: string) => {
        setCart(prevCart => prevCart.filter(item => item.id !== productId));
    };

    const updateCartQuantity = (productId: string, quantity: number) => {
        if (quantity <= 0) {
            removeFromCart(productId);
            return;
        }
        setCart(prevCart =>
            prevCart.map(item =>
                item.id === productId ? { ...item, quantity } : item
            )
        );
    };

    const clearCart = () => {
        setCart([]);
    };

    const exportSettings = () => {
        const settings = {
            siteName,
            products,
            categories,
            adminCredentials,
        };
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(settings, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "luxelane-settings.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
        alert('Settings exported successfully!');
    };

    const importSettings = (file: File): Promise<void> => {
        return new Promise((resolve, reject) => {
            if (!file || file.type !== 'application/json') {
                alert('Please upload a valid .json file.');
                return reject(new Error('Invalid file type.'));
            }

            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const text = event.target?.result;
                    if (typeof text !== 'string') throw new Error("Failed to read file content.");
                    
                    const settings = JSON.parse(text);

                    if (settings.siteName && Array.isArray(settings.products) && Array.isArray(settings.categories) && settings.adminCredentials) {
                        setSiteName(settings.siteName);
                        setProducts(settings.products);
                        setCategories(settings.categories);
                        setAdminCredentials(settings.adminCredentials);
                        alert('Settings imported successfully!');
                        resolve();
                    } else {
                        alert('The imported file has an invalid format.');
                        reject(new Error('Invalid file format.'));
                    }
                } catch (error) {
                    console.error("Error parsing settings file:", error);
                    alert('There was an error reading or parsing the settings file.');
                    reject(error);
                }
            };
            reader.onerror = (error) => {
                 alert('Failed to read the file.');
                 reject(error);
            };
            reader.readAsText(file);
        });
    };


    const value = useMemo(() => ({
        siteName,
        setSiteName,
        products,
        setProducts,
        categories,
        setCategories,
        isAdmin,
        login,
        logout,
        adminEmail: adminCredentials.email,
        updateAdminCredentials,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,
        deleteCategory,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        exportSettings,
        importSettings,
        view,
        setView,
        selectedProduct,
        setSelectedProduct,
    }), [siteName, products, categories, isAdmin, login, logout, adminCredentials.email, updateAdminCredentials, cart, view, selectedProduct]);

    return (
        <AppContext.Provider value={value}>
            {children}
        </AppContext.Provider>
    );
};