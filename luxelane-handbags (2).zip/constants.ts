import type { Product, Category } from './types';

export const INITIAL_SITE_NAME = 'LuxeLane Handbags';

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'All Handbags' },
  { id: '2', name: 'Tote Bags' },
  { id: '3', name: 'Crossbody Bags' },
  { id: '4', name: 'Clutches' },
  { id: '5', name: 'Shoulder Bags' },
];

// A NEW, larger, and more reliable curated list of high-quality handbag images to guarantee visibility.
export const HANDBAG_IMAGE_URLS = [
  "https://images.pexels.com/photos/1040384/pexels-photo-1040384.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3907507/pexels-photo-3907507.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2534961/pexels-photo-2534961.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1374910/pexels-photo-1374910.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2442904/pexels-photo-2442904.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1578997/pexels-photo-1578997.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3621743/pexels-photo-3621743.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3775693/pexels-photo-3775693.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/45981/pexels-photo-45981.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2305098/pexels-photo-2305098.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1484771/pexels-photo-1484771.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1908013/pexels-photo-1908013.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1346213/pexels-photo-1346213.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1457920/pexels-photo-1457920.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2647053/pexels-photo-2647053.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3414327/pexels-photo-3414327.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3738096/pexels-photo-3738096.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/4222941/pexels-photo-4222941.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1639735/pexels-photo-1639735.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2081125/pexels-photo-2081125.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2043603/pexels-photo-2043603.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2421374/pexels-photo-2421374.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1113824/pexels-photo-1113824.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2896590/pexels-photo-2896590.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3540974/pexels-photo-3540974.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/1356276/pexels-photo-1356276.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/2552899/pexels-photo-2552899.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1",
  "https://images.pexels.com/photos/3321523/pexels-photo-3321523.jpeg?auto=compress&cs=tinysrgb&w=600&h=750&dpr=1"
];


export const generateMockProducts = (count: number): Product[] => {
  const products: Product[] = [];
  const categories = INITIAL_CATEGORIES.filter(c => c.name !== 'All Handbags');
  
  const adjectives = ["Chic", "Elegant", "Stylish", "Luxury", "Classic", "Modern", "Bohemian", "Vintage", "Urban", "Sleek"];
  const materials = ["Leather", "Canvas", "Suede", "Velvet", "Woven", "Faux Fur", "Nylon", "Straw"];

  for (let i = 1; i <= count; i++) {
    const category = categories[i % categories.length];
    const bagType = category.name.slice(0, -1); // "Tote Bags" -> "Tote Bag"
    
    const adjective = adjectives[Math.floor(Math.random() * adjectives.length)];
    const material = materials[Math.floor(Math.random() * materials.length)];
    
    // Create more realistic names
    let productName = `${adjective} ${bagType}`;
    if(Math.random() > 0.5) {
        productName = `${adjective} ${material} ${bagType}`;
    }

    products.push({
      id: `prod-${Date.now()}-${i}`,
      name: productName,
      price: parseFloat((Math.random() * (300 - 50) + 50).toFixed(2)),
      // Use the reliable, curated list of images.
      imageUrl: HANDBAG_IMAGE_URLS[i % HANDBAG_IMAGE_URLS.length],
      description: `A beautifully crafted ${productName.toLowerCase()}. This ${category.name.toLowerCase()} combines style and functionality with its spacious compartments and elegant design. Made from high-quality materials, it's a must-have accessory.`,
      category: category.name,
    });
  }
  return products;
};

export const INITIAL_PRODUCTS: Product[] = generateMockProducts(120);